 const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const MONGO_URI = "mongodb://a24308051280789:gallardo0789@ac-quwasum-shard-00-00.qvcoil8.mongodb.net:27017,ac-quwasum-shard-00-01.qvcoil8.mongodb.net:27017,ac-quwasum-shard-00-02.qvcoil8.mongodb.net:27017/test?ssl=true&replicaSet=atlas-was61r-shard-0&authSource=admin&retryWrites=true&w=majority";

mongoose.connect(MONGO_URI)
    .then(() => console.log("Conectado a MongoDB Atlas OK"))
    .catch(err => console.error("Error conexion:", err.message));

// MODELOS

const clienteSchema = new mongoose.Schema({
    id_cliente:      { type: String, default: '' },
    nombre_cliente:  { type: String, default: '' },
    telefono:        { type: String, default: '' },
    direccion:       { type: String, default: '' },
    email:           { type: String, default: '' },
    id_mascota:      { type: String, default: '' },
    nombre_mascota:  { type: String, default: '' },
    especie_mascota: { type: String, default: '' }
}, { collection: 'clientes', strict: false, versionKey: false });

const mascotaSchema = new mongoose.Schema({
    id_mascota:          { type: String, default: '' },
    nombre_mascota:      { type: String, default: '' },
    especie:             { type: String, default: '' },
    raza:                { type: String, default: '' },
    genero:              { type: String, default: '' },
    id_dueno:            { type: String, default: '' },
    num_chip:            { type: String, default: '' },
    caracteristicas_esp: { type: String, default: '' },
    estancia:            { type: String, default: '' }
}, { collection: 'mascotas', strict: false, versionKey: false });

const veterinarioSchema = new mongoose.Schema({
    id_veterinario: { type: String, default: '' },
    nombre_vet:     { type: String, default: '' },
    especialidad:   { type: String, default: '' },
    cedula:         { type: String, default: '' },
    telefono:       { type: String, default: '' },
    consultorio:    { type: String, default: '' },
    turno:          { type: String, default: '' },
    estado:         { type: String, default: '' },
    dias:           { type: [String], default: [] }
}, { collection: 'veterinarios', strict: false, versionKey: false });

const citaSchema = new mongoose.Schema({
    id_cita:     { type: String, default: '' },
    id_mascota:  { type: String, default: '' },
    id_vet:      { type: String, default: '' },
    fecha:       { type: String, default: '' },
    peso:        { type: Number, default: 0 },
    temp:        { type: Number, default: 0 },
    diagnostico: { type: String, default: '' },
    tratamiento: { type: String, default: '' },
    costo:       { type: Number, default: 0 }
}, { collection: 'citas', strict: false, versionKey: false });

const historialSchema = new mongoose.Schema({
    id_historial:   { type: String, default: '' },
    id_mascota:     { type: String, default: '' },
    nombre_mascota: { type: String, default: '' },
    id_vet:         { type: String, default: '' },
    fecha:          { type: String, default: '' },
    peso:           { type: Number, default: 0 },
    temp:           { type: Number, default: 0 },
    frec_card:      { type: Number, default: 0 },
    mucosas:        { type: String, default: '' },
    proceso:        { type: String, default: '' },
    resultado:      { type: String, default: '' },
    vacuna:         { type: String, default: '' }
}, { collection: 'mascotas_historial', strict: false, versionKey: false });

const Cliente     = mongoose.model('Cliente',     clienteSchema);
const Mascota     = mongoose.model('Mascota',     mascotaSchema);
const Veterinario = mongoose.model('Veterinario', veterinarioSchema);
const Cita        = mongoose.model('Cita',        citaSchema);
const Historial   = mongoose.model('Historial',   historialSchema);

// RUTAS CLIENTES
app.get('/api/clientes', async (req, res) => {
    try { res.json(await Cliente.find()); }
    catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/clientes', async (req, res) => {
    try {
        console.log('POST clientes body:', req.body);
        const nuevo = new Cliente(req.body);
        await nuevo.save();
        console.log('Guardado:', nuevo.toObject());
        res.status(201).json({ mensaje: 'Cliente guardado', data: nuevo });
    } catch (e) {
        console.error('Error POST clientes:', e.message);
        res.status(400).json({ error: e.message });
    }
});
app.put('/api/clientes/:id', async (req, res) => {
    try {
        const actualizado = await Cliente.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!actualizado) return res.status(404).json({ error: 'No encontrado' });
        res.json({ mensaje: 'Cliente actualizado', data: actualizado });
    } catch (e) { res.status(400).json({ error: e.message }); }
});
app.delete('/api/clientes/:id', async (req, res) => {
    try {
        const eliminado = await Cliente.findByIdAndDelete(req.params.id);
        if (!eliminado) return res.status(404).json({ error: 'No encontrado' });
        res.json({ mensaje: 'Cliente eliminado' });
    } catch (e) { res.status(400).json({ error: e.message }); }
});

// RUTAS MASCOTAS
app.get('/api/mascotas', async (req, res) => {
    try { res.json(await Mascota.find()); }
    catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/mascotas', async (req, res) => {
    try {
        const nuevo = new Mascota(req.body);
        await nuevo.save();
        res.status(201).json({ mensaje: 'Mascota registrada', data: nuevo });
    } catch (e) { res.status(400).json({ error: e.message }); }
});
app.put('/api/mascotas/:id', async (req, res) => {
    try {
        const actualizado = await Mascota.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!actualizado) return res.status(404).json({ error: 'No encontrada' });
        res.json({ mensaje: 'Mascota actualizada', data: actualizado });
    } catch (e) { res.status(400).json({ error: e.message }); }
});
app.delete('/api/mascotas/:id', async (req, res) => {
    try {
        const eliminado = await Mascota.findByIdAndDelete(req.params.id);
        if (!eliminado) return res.status(404).json({ error: 'No encontrada' });
        res.json({ mensaje: 'Mascota eliminada' });
    } catch (e) { res.status(400).json({ error: e.message }); }
});

// RUTAS VETERINARIOS
app.get('/api/veterinarios', async (req, res) => {
    try { res.json(await Veterinario.find()); }
    catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/veterinarios', async (req, res) => {
    try {
        const nuevo = new Veterinario(req.body);
        await nuevo.save();
        res.status(201).json({ mensaje: 'Veterinario registrado', data: nuevo });
    } catch (e) { res.status(400).json({ error: e.message }); }
});
app.put('/api/veterinarios/:id', async (req, res) => {
    try {
        const actualizado = await Veterinario.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!actualizado) return res.status(404).json({ error: 'No encontrado' });
        res.json({ mensaje: 'Veterinario actualizado', data: actualizado });
    } catch (e) { res.status(400).json({ error: e.message }); }
});
app.delete('/api/veterinarios/:id', async (req, res) => {
    try {
        const eliminado = await Veterinario.findByIdAndDelete(req.params.id);
        if (!eliminado) return res.status(404).json({ error: 'No encontrado' });
        res.json({ mensaje: 'Veterinario eliminado' });
    } catch (e) { res.status(400).json({ error: e.message }); }
});

// RUTAS CITAS
app.get('/api/citas', async (req, res) => {
    try { res.json(await Cita.find()); }
    catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/citas', async (req, res) => {
    try {
        const nuevo = new Cita(req.body);
        await nuevo.save();
        res.status(201).json({ mensaje: 'Cita agendada', data: nuevo });
    } catch (e) { res.status(400).json({ error: e.message }); }
});
app.put('/api/citas/:id', async (req, res) => {
    try {
        const actualizado = await Cita.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!actualizado) return res.status(404).json({ error: 'No encontrada' });
        res.json({ mensaje: 'Cita actualizada', data: actualizado });
    } catch (e) { res.status(400).json({ error: e.message }); }
});
app.delete('/api/citas/:id', async (req, res) => {
    try {
        const eliminado = await Cita.findByIdAndDelete(req.params.id);
        if (!eliminado) return res.status(404).json({ error: 'No encontrada' });
        res.json({ mensaje: 'Cita eliminada' });
    } catch (e) { res.status(400).json({ error: e.message }); }
});

// RUTAS HISTORIAL
app.get('/api/historial', async (req, res) => {
    try { res.json(await Historial.find()); }
    catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/historial', async (req, res) => {
    try {
        const nuevo = new Historial(req.body);
        await nuevo.save();
        res.status(201).json({ mensaje: 'Historial guardado', data: nuevo });
    } catch (e) { res.status(400).json({ error: e.message }); }
});
app.put('/api/historial/:id', async (req, res) => {
    try {
        const actualizado = await Historial.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!actualizado) return res.status(404).json({ error: 'No encontrado' });
        res.json({ mensaje: 'Historial actualizado', data: actualizado });
    } catch (e) { res.status(400).json({ error: e.message }); }
});
app.delete('/api/historial/:id', async (req, res) => {
    try {
        const eliminado = await Historial.findByIdAndDelete(req.params.id);
        if (!eliminado) return res.status(404).json({ error: 'No encontrado' });
        res.json({ mensaje: 'Historial eliminado' });
    } catch (e) { res.status(400).json({ error: e.message }); }
});

// INICIAR SERVIDOR
app.listen(5000, () => console.log('Servidor corriendo en http://localhost:5000'));
